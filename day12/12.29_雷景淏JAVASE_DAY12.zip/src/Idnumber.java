public class Idnumber extends Exception {
    public Idnumber(){
        super("这是逃犯");
    }

}
