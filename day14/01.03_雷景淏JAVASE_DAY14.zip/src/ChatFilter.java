import java.util.Scanner;

public class ChatFilter {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        System.out.println("请开始聊天，注意文明用语");
       String str=input.nextLine();
       boolean a=str.contains("尼玛");
       boolean b=str.contains("我擦");
       if(a||b){
          str= str.replaceAll("尼玛","**");
          str= str.replaceAll("我擦","**");
           System.out.println(str);
       }
       else{
           System.out.println(str);
       }

    }
}
