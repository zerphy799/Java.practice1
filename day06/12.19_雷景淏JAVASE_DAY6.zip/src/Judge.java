public class Judge {
    public static void main() {
    int[] x={1,5,4,2,5,20};
    int b=1;
    for(int i=0;i<x.length;i++){
        if(x[i]>x[i+1]){
            System.out.println("这个函数无序");
            b=0;
            break;
        }

    }
    if(b==1){
        System.out.println("这个函数有序");
    }

    }
}
