public class Employee01 extends Staff {
    private String name;

    public Employee01() {
        super();
        name="杜甫";
    }

    public String getName() {
        return name;
    }
}
