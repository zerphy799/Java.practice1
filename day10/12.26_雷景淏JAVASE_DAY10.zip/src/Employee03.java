public class Employee03 extends Staff{
    private String name;

    public Employee03() {
        super();
        name="李商隐";
    }

    public String getName() {
        return name;
    }
}
