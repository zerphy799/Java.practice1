public class Employee02 extends Staff {
    private String name;

    public Employee02() {
        super();
        name="白居易";
    }

    public String getName() {
        return name;
    }
}
