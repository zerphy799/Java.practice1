import java.util.Scanner;

public class Work03 {
    public static void main(String[] args){
        float num;
        System.out.println("请输入一个数字");
        Scanner input = new Scanner(System.in);
        num = input.nextFloat();
        int num1;
        num1=(int)(num*100+0.5);
        num=(float)num1/100;
        System.out.println(num);
    }
}
