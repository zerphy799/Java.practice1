import java.util.Scanner;

public class Work03 {
    static void main() {
        float num;
        Scanner input = new Scanner(System.in);
        System.out.println("请输入一个小数" );
        num=input.nextFloat();
        num= Float.parseFloat(String.format("%.2f",num));
        System.out.println(num);
    }
}
