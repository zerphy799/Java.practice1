package com.xzit;

public class test {
    static void main() {
        System.out.println("     交通银行");
        System.out.println("   欢迎光临交通银行");
        System.out.println("您需办理的业务是:现金汇款");
        System.out.println("    您的排队号是:");
        System.out.println(" 您前面还有等待的人数:11");
        System.out.println( "2014-10-15     09:39:05");
        System.out.println("温馨提示:业务办理需要携带身份证等有效证件");
    }
}
