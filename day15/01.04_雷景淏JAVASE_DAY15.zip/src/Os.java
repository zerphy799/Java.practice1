public enum Os {
    Windows,
        Linux;
}
