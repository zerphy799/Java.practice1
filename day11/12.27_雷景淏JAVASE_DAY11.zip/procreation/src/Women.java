public class Women implements God{
    public Women() {
    }

    public void say(){
        System.out.println("女人说话");
    }
    public void eat(){
        System.out.println("女人吃东西");
    }
    public void sleep(){
        System.out.println("女人睡觉");
    }
}
