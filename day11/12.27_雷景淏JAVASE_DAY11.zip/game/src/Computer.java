public class Computer {
   private String station;
   private int runningMemory;

    public int getRunningMemory() {
        return runningMemory;
    }

    public void setRunningMemory(int runningMemory) {
        this.runningMemory = runningMemory;
    }

    public String getStation() {
        return station;
    }

    public void setStation(String station) {
        this.station = station;
    }
}
