public interface God {
    void say();
    void eat();
    void sleep();
}
