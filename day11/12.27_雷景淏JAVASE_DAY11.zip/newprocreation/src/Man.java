public class Man implements God {
    @Override
    public void say() {
        System.out.println("男人说话");
    }
    @Override
    public void eat() {
        System.out.println("男人吃东西");
    }
    @Override
    public void sleep() {
        System.out.println("男人睡觉");
    }
}
