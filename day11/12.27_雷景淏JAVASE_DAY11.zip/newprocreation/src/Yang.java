public class Yang {
    public static God man(){
        return new Man();
    }
}
