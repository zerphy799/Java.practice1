public class Test {
    public static void main(String[] args) {
        God man=Yang.man();
        God women=Yin.women();
        man.eat();
        women.eat();
        man.say();
        women.say();
        man.sleep();
        women.sleep();
    }
}
