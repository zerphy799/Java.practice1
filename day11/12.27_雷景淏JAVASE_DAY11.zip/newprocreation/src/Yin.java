public class Yin {
    public static God women(){
        return new Women();
    }
}
