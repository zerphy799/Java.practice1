public class LibaryCard {
   private String color="红色";
   private char type;

    public LibaryCard() {
    }

    public String getColor() {
        return color;
    }

    public char getType() {
        return type;
    }

    public void setType(char type) {
        this.type = type;
    }
}
