public class Test {
    public static void main(String[] args) {

        Manager manager = new Manager('A');
        manager.brow();
        Manager manager1 = new Manager('B');
        manager1.brow();
        Manager manager2 = new Manager('C');
        manager2.brow();


    }
}
